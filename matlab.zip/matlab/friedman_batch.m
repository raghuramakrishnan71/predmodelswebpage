techniques = {'1-rbfreg', '3-pacer', '4-isor', '5-lms', '6-mlp', '7-lr', '8-slr', '9-smo', '10-dt', '11-m5r', '12-zr', '13-m5p', '14-ds', '15-randfor', '16-randtree', '17-reptree', '18-ibk', '19-lwl'};
alpha = 0.05;
filenames= readtable('friedman_list2.txt', 'Delimiter','\n', 'Delimiter',' ');
ssz = size(filenames);
rows= ssz(1);

fprintf('Rows = %d\n', rows);
for nn = 1:rows
    filename = filenames{nn,1};
    dataset  = csvread(char(filename));
    [p,tbl,stats] = friedman(dataset, 1, 'off');
    minrank = min(stats.meanranks);
    fprintf('RankPos %d\n', minrank);
    minranktechniquepos = find (stats.meanranks == minrank);
    sszz = size(minranktechniquepos);
    cols = sszz(2);
    for nnn = 1:cols
        fprintf('Print %d\n', minranktechniquepos(nnn));
        minranktechnique = techniques(minranktechniquepos(nnn));

        c = multcompare(stats, 'Alpha', alpha, 'CType', 'bonferroni', 'Display', 'on');
        z = c(:, [1,2,6]);
        s = length(z);

        fprintf('%s|%s|%0.3f|', char(filename), char(minranktechnique), p);
        for n = 1:s
           if z(n,1) == minranktechniquepos
               if z(n,3) > alpha
                   fprintf('<%s,%0.3f>', char(techniques(z(n,2))), z(n,3)); 
               end
           elseif z(n,2) == minranktechniquepos
               if z(n,3) > alpha
                   fprintf('<%s %0.3f>', char(techniques(z(n,1))), z(n,3)); 
               end
           end
        end
        fprintf('\n');
    end
end
