#!/bin/bash
CLAZZ_PATH="-cp /home/anakinskywalker/weka-3-8-1/weka.jar:/home/anakinskywalker/weka-3-8-1/mtj.jar:/home/anakinskywalker/weka-3-8-1/model-eval.jar:/home/anakinskywalker/jars/commons-cli-1.4.jar:/home/anakinskywalker/jars/commons-csv-1.5.jar:/home/anakinskywalker/jars/commons-math3-3.6.1.jar:/home/anakinskywalker/wekafiles/packages/isotonicRegression/isotonicRegression.jar:/home/anakinskywalker/wekafiles/packages/leastMedSquared/leastMedSquared.jar:/home/anakinskywalker/wekafiles/packages/paceRegression/paceRegression.jar:/home/anakinskywalker/wekafiles/packages/RBFNetwork/RBFNetwork.jar"
JVM_MEM=-Xmx3072m

usage()
{
	echo "usage: step4 [[-i inputfilelist -s setdir] | [-h]]"
}

echo "No of parameters" $#

if [ $# -ne 4 ]; then
	usage
	exit
fi

while [ "$1" != "" ]; do
	case $1 in
		-i | --ifile )	shift
						INPUT=$1
						;;
        -s | --setdir ) shift
						SET_LOCATION=$1
                        ;;
		-h | --help )   usage
                        exit
                        ;;
		* )				usage
						exit 1
	esac
	shift
done

#main
DIFF=0

echo "Cleaning results file"
> ${SET_LOCATION}/results/evaluation.csv


while IFS= read -r var
do

echo "${SET_LOCATION}/input/${var}_onload.arff"

#5 RBF regression
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_rbfreg.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_rbfreg" -append true -etime $DIFF -debug false -technique rbfreg -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_rbfreg.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_rbfreg" -append true -etime $DIFF -debug false -technique rbfreg -v true

#6 RBF network
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_rbfnet.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_rbfnet" -append true -etime $DIFF -debug false -technique rbfnet -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_rbfnet.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_rbfnet" -append true -etime $DIFF -debug false -technique rbfnet -v true
 
#7 pace regression
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_pacer.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_pacer" -append true -etime $DIFF -debug false -technique pacer -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_pacer.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_pacer" -append true -etime $DIFF -debug false -technique pacer -v true

#8 isotonic regression
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_isor.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_isor" -append true -etime $DIFF -debug false -technique isor -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_isor.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_isor" -append true -etime $DIFF -debug false -technique isor -v true

#9 Least median square
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_lms.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_lms" -append true -etime $DIFF -debug false -technique lms -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_lms.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_lms" -append true -etime $DIFF -debug false -technique lms -v true

#10 mlp
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_mlp.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_mlp" -append true -etime $DIFF -debug false -technique mlp -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_mlp.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_mlp" -append true -etime $DIFF -debug false -technique mlp -v true

#11 mlr, change S to 1 - attribute selection method None
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_lr.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_lr" -append true -etime $DIFF -debug false -technique lr -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_lr.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_lr" -append true -etime $DIFF -debug false -technique lr -v true

#12 slr
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_slr.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_slr" -append true -etime $DIFF -debug false -technique slr -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_slr.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_slr" -append true -etime $DIFF -debug false -technique slr -v true

#13 smo
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_smo.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_smo" -append true -etime $DIFF -debug false -technique smo -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_smo.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_smo" -append true -etime $DIFF -debug false -technique smo -v true

#14 dt
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_dt.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_dt" -append true -etime $DIFF -debug false -technique dt -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_dt.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_dt" -append true -etime $DIFF -debug false -technique dt -v true

#15 m5rules
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_m5r.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_m5r" -append true -etime $DIFF -debug false -technique m5r -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_m5r.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_m5r" -append true -etime $DIFF -debug false -technique m5r -v true

#16 zr
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_zr.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_zr" -append true -etime $DIFF -debug false -technique zr -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_zr.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_zr" -append true -etime $DIFF -debug false -technique zr -v true

#17 m5p
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_m5p.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_m5p" -append true -etime $DIFF -debug false -technique m5p -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_m5p.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_m5p" -append true -etime $DIFF -debug false -technique m5p -v true

#18 ds
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_ds.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_ds" -append true -etime $DIFF -debug false -technique ds -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_ds.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_ds" -append true -etime $DIFF -debug false -technique ds -v true

#19 randforest
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_randfor.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_randfor" -append true -etime $DIFF -debug false -technique randfor -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_randfor.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_randfor" -append true -etime $DIFF -debug false -technique randfor -v true

#20 randtree
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_randtree.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_randtree" -append true -etime $DIFF -debug false -technique randtree -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_randtree.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_randtree" -append true -etime $DIFF -debug false -technique randtree -v true

#21 reptree
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_reptree.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_reptree" -append true -etime $DIFF -debug false -technique reptree -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_reptree.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_reptree" -append true -etime $DIFF -debug false -technique reptree -v true

#22 Ibk
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_ibk.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_ibk" -append true -etime $DIFF -debug false -technique ibk -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_ibk.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_ibk" -append true -etime $DIFF -debug false -technique ibk -v true

#23 Kstar

#24 LWL
java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_lwl.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_lwl" -append true -etime $DIFF -debug false -technique lwl -v false

#java $CLAZZ_PATH $JVM_MEM model.evaluation.ModelPerformance -i1 ${SET_LOCATION}/output/${var}_avp_lwl.csv -i2 ${SET_LOCATION}/output/${var}_avp_zr.csv -o ${SET_LOCATION}/results/evaluation.csv -p1 0.25 -p2 0.30 -label "${SET_LOCATION}/input/${var}_lwl" -append true -etime $DIFF -debug false -technique lwl -v true

done < "$INPUT"
