#!/bin/bash
CLAZZ_PATH="-cp /home/anakinskywalker/weka-3-8-1/weka.jar:/home/anakinskywalker/weka-3-8-1/mtj.jar:/home/anakinskywalker/weka-3-8-1/model-eval.jar:/home/anakinskywalker/jars/commons-cli-1.4.jar:/home/anakinskywalker/jars/commons-csv-1.5.jar:/home/anakinskywalker/jars/commons-math3-3.6.1.jar:/home/anakinskywalker/wekafiles/packages/isotonicRegression/isotonicRegression.jar:/home/anakinskywalker/wekafiles/packages/leastMedSquared/leastMedSquared.jar:/home/anakinskywalker/wekafiles/packages/paceRegression/paceRegression.jar:/home/anakinskywalker/wekafiles/packages/RBFNetwork/RBFNetwork.jar"
JVM_MEM=-Xmx3072m

usage()
{
	echo "usage: step3 [[-i inputfilelist -s setdir] | [-h]]"
}

echo "No of parameters" $#

if [ $# -ne 4 ]; then
	usage
	exit
fi

while [ "$1" != "" ]; do
	case $1 in
		-i | --ifile )	shift
						INPUT=$1
						;;
        -s | --setdir ) shift
						SET_LOCATION=$1
                        ;;
		-h | --help )   usage
                        exit
                        ;;
		* )				usage
						exit 1
	esac
	shift
done

#main

echo "Cleaning results file"
> ${SET_LOCATION}/results/evaluation.csv


while IFS= read -r var
do

echo "${SET_LOCATION}/input/${var}_onload.arff"

#5 RBF regression
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.functions.RBFRegressor -N 2 -R 0.01 -L 1.0E-6 -C 2 -P 1 -E 1 -S 1  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_rbfreg.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "rbf regression  $START $END $DIFF seconds"

#6 RBF network
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.functions.RBFNetwork -B 2 -S 1 -R 1.0E-8 -M -1 -W 0.1  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_rbfnet.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "rbf network took $START $END $DIFF seconds"

#7 pace regression
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.functions.PaceRegression -E eb  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_pacer.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "pace regression took $START $END $DIFF seconds"

#8 isotonic regression
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.functions.IsotonicRegression  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_isor.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "isotonic regression took $START $END $DIFF seconds"

#9 Least median square
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.functions.LeastMedSq -S 4 -G 0  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_lms.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Leastmediansquare took $START $END $DIFF seconds"

#10 mlp
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.functions.MultilayerPerceptron -L 0.3 -M 0.2 -N 500 -V 0 -S 0 -E 20 -H a  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_mlp.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Mlp took $START $END $DIFF seconds"

#11 mlr, change S to 1 - attribute selection method None
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.functions.LinearRegression -S 1 -R 1.0E-8 -num-decimal-places 4   -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last  -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_lr.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Mlr took $START $END $DIFF seconds"

#12 slr
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.functions.SimpleLinearRegression  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_slr.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Slr took $START $END $DIFF seconds"

#13 smo
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.functions.SMOreg -C 1.0 -N 0 -I "weka.classifiers.functions.supportVector.RegSMOImproved -T 0.001 -V -P 1.0E-12 -L 0.001 -W 1" -K "weka.classifiers.functions.supportVector.PolyKernel -E 1.0 -C 250007"  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_smo.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Smo took $START $END $DIFF seconds"

#14 dt
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.rules.DecisionTable -X 1 -S "weka.attributeSelection.BestFirst -D 1 -N 5"  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_dt.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Dt took $START $END $DIFF seconds"

#15 m5rules
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.rules.M5Rules -M 4.0  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_m5r.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "M5rules took $START $END $DIFF seconds"

#16 zr
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.rules.ZeroR  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_zr.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Zr took $START $END $DIFF seconds"

#17 m5p
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.trees.M5P -M 4.0  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_m5p.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "M5p took $START $END $DIFF seconds"

#18 ds
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.trees.DecisionStump  -t  "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last  -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_ds.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Ds took $START $END $DIFF seconds"

#19 randforest
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.trees.RandomForest -P 100 -I 100 -num-slots 1 -K 0 -M 1.0 -V 0.001 -S 1  -t  "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last  -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_randfor.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Randforest took $START $END $DIFF seconds"

#20 randtree
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.trees.RandomTree -K 0 -M 1.0 -V 0.001 -S 1  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last  -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_randtree.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Randtree took $START $END $DIFF seconds"

#21 reptree
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.trees.REPTree -M 2 -V 0.001 -N 3 -S 1 -L -1 -I 0.0  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last  -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_reptree.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Reptree took $START $END $DIFF seconds"

#22 Ibk
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.lazy.IBk -K 1 -W 0 -A "weka.core.neighboursearch.LinearNNSearch -A \"weka.core.EuclideanDistance -R first-last\""   -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last  -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_ibk.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Ibk took $START $END $DIFF seconds"

#23 Kstar
START=$(date +%s)
#java $CLAZZ_PATH $JVM_MEM weka.classifiers.lazy.KStar -B 20 -M a  -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last  -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_kstar.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "Kstar took $START $END $DIFF seconds"

#24 LWL
START=$(date +%s)
java $CLAZZ_PATH $JVM_MEM weka.classifiers.lazy.LWL -U 0 -K -1 -A "weka.core.neighboursearch.LinearNNSearch -A \"weka.core.EuclideanDistance -R first-last\"" -W weka.classifiers.trees.DecisionStump -t "${SET_LOCATION}/input/${var}_onload.arff" -x 10 -c last  -classifications "weka.classifiers.evaluation.output.prediction.CSV -file ${SET_LOCATION}/output/${var}_avp_lwl.csv"
END=$(date +%s)
DIFF=$(( $END - $START ))
echo "LWL took $START $END $DIFF seconds"

done < "$INPUT"
