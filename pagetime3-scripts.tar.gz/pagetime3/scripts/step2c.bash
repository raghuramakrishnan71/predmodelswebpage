#!/bin/bash
CLAZZ_PATH="-cp /home/anakinskywalker/weka-3-8-1/weka.jar:/home/anakinskywalker/weka-3-8-1/mtj.jar:/home/anakinskywalker/weka-3-8-1/model-eval.jar:/home/anakinskywalker/jars/commons-cli-1.4.jar:/home/anakinskywalker/jars/commons-csv-1.5.jar:/home/anakinskywalker/jars/commons-math3-3.6.1.jar:/home/anakinskywalker/wekafiles/packages/isotonicRegression/isotonicRegression.jar:/home/anakinskywalker/wekafiles/packages/leastMedSquared/leastMedSquared.jar:/home/anakinskywalker/wekafiles/packages/paceRegression/paceRegression.jar:/home/anakinskywalker/wekafiles/packages/RBFNetwork/RBFNetwork.jar"
JVM_MEM=-Xmx3072m
RANDOM_SEED=967825

usage()
{
	echo "usage: step2c [[-i inputfilelist -r randdir -s setdir] | [-h]]"
}

echo "No of parameters" $#

if [ $# -ne 6 ]; then
	usage
	exit
fi

while [ "$1" != "" ]; do
	case $1 in
		-i | --ifile )	shift
						INPUT=$1
						;;
        -r | --randdir )shift
						RANDOM_LOCATION=$1
                        ;;
        -s | --setdir ) shift
						SET_LOCATION=$1
                        ;;
		-h | --help )   usage
                        exit
                        ;;
		* )				usage
						exit 1
	esac
	shift
done

#main

while IFS= read -r var
do

#truncate dataset to include attributes relevant for set 2
#onLoad, reqTotal, reqJS, reqCSS, reqImg, bytesTotal, bytesJS, bytesCSS, bytesImg, numDomains, 
#numThirdParty2, bytesThirdParty2, reqThirdParty2
echo "Creating data file for Set 3 (${var})"

#revised set 2
#onLoad (1), reqJS (4), reqCSS (5), reqCSS (6), bytesJS (22), bytesCSS (23), bytesImg (24), numDomains (39), numThirdParty2 (48)
#bytesThirdParty2 (49), reqThirdParty2 (50), bytesNonJsCsImg (54), reqNonJsCsImg (55)
#java $CLAZZ_PATH $JVM_MEM weka.filters.unsupervised.attribute.Remove -R 2,4-6,20,22-24,39,41-44,45-47,48-50,1 -V -i "${RANDOM_LOCATION}/${var}_onload.arff" -o "${SET_LOCATION}/input/${var}_onload.arff"

java $CLAZZ_PATH $JVM_MEM weka.filters.unsupervised.attribute.Remove -R 4-6,22-24,39,48-50,54-55,1 -V -i "${RANDOM_LOCATION}/${var}_onload.arff" -o "${SET_LOCATION}/input/${var}_onload.arff"


done < "$INPUT"
