#!/bin/bash
CLAZZ_PATH="-cp /home/anakinskywalker/weka-3-8-1/weka.jar:/home/anakinskywalker/weka-3-8-1/mtj.jar:/home/anakinskywalker/weka-3-8-1/model-eval.jar:/home/anakinskywalker/jars/commons-cli-1.4.jar:/home/anakinskywalker/jars/commons-csv-1.5.jar:/home/anakinskywalker/jars/commons-math3-3.6.1.jar"
JVM_MEM=-Xmx3072m
RANDOM_SEED=967825

usage()
{
	echo "usage: step [[-i inputfilelist -c csvdir -a arffdir -r randdir] | [-h]]"
}

echo "No of parameters" $#

if [ $# -ne 8 ]; then
	usage
	exit
fi

while [ "$1" != "" ]; do
	case $1 in
		-i | --ifile )	shift
						INPUT=$1
						;;
        -c | --csvdir )	shift
						CSV_LOCATION=$1
                        ;;
        -a | --arffdir )shift
						ARFF_LOCATION=$1
                        ;;
        -r | --randdir )shift
						RANDOM_LOCATION=$1
                        ;;
		-h | --help )   usage
                        exit
                        ;;
		* )				usage
						exit 1
	esac
	shift
done

#main

while IFS= read -r var
do

COUNT=`cat ${CSV_LOCATION}/${var}.csv|wc -l`

echo "Processing ${var} = `expr ${COUNT} - 1`"

#convert csv to arff
echo "Converting to arff"
java $CLAZZ_PATH $JVM_MEM weka.core.converters.CSVLoader "${CSV_LOCATION}/${var}.csv" -S "1-3"  > "${ARFF_LOCATION}/${var}.arff"

#randomize contents of arff
echo "Randomizing arff file"
java $CLAZZ_PATH $JVM_MEM weka.filters.unsupervised.instance.Randomize -S $RANDOM_SEED -i "${ARFF_LOCATION}/${var}.arff" -o "${RANDOM_LOCATION}/${var}_randomized.arff"

#truncate dataset to include attributes relevant for onload
echo "Creating onload data file"
java $CLAZZ_PATH $JVM_MEM weka.filters.unsupervised.attribute.Remove -R 1-4,6-12,56-60,64-66 -i "${RANDOM_LOCATION}/${var}_randomized.arff" -o "${RANDOM_LOCATION}/${var}_onload.arff"

done < "$INPUT"

COUNT=`ls ${CSV_LOCATION}/*.csv | wc -l`
echo "Total csv files = ${COUNT}"
COUNT=`ls ${ARFF_LOCATION}/*.arff | wc -l`
echo "Total arff files = ${COUNT}"
COUNT=`ls ${RANDOM_LOCATION}/*_randomized.arff | wc -l`
echo "Total randomized arff files = ${COUNT}"
