#!/bin/bash
CLAZZ_PATH="-cp /home/anakinskywalker/weka-3-8-1/weka.jar:/home/anakinskywalker/weka-3-8-1/mtj.jar:/home/anakinskywalker/weka-3-8-1/model-eval.jar:/home/anakinskywalker/jars/commons-cli-1.4.jar:/home/anakinskywalker/jars/commons-csv-1.5.jar:/home/anakinskywalker/jars/commons-math3-3.6.1.jar:/home/anakinskywalker/wekafiles/packages/isotonicRegression/isotonicRegression.jar:/home/anakinskywalker/wekafiles/packages/leastMedSquared/leastMedSquared.jar:/home/anakinskywalker/wekafiles/packages/paceRegression/paceRegression.jar:/home/anakinskywalker/wekafiles/packages/RBFNetwork/RBFNetwork.jar"
JVM_MEM=-Xmx3072m

usage()
{
	echo "usage: step2d [[-i inputfilelist -r randdir -s setdir] | [-h]]"
}

echo "No of parameters" $#

if [ $# -ne 6 ]; then
	usage
	exit
fi

while [ "$1" != "" ]; do
	case $1 in
		-i | --ifile )	shift
						INPUT=$1
						;;
        -r | --randdir )shift
						RANDOM_LOCATION=$1
                        ;;
        -s | --setdir ) shift
						SET_LOCATION=$1
                        ;;
		-h | --help )   usage
                        exit
                        ;;
		* )				usage
						exit 1
	esac
	shift
done

#main

echo "Cleaning results files"
>  ${SET_LOCATION}/results/top_features_bf.csv


while IFS= read -r var
do

#attributes selection for set 4
echo "Selecting attributes using BestFit for Set 4 (${var})"
java $CLAZZ_PATH $JVM_MEM weka.filters.supervised.attribute.AttributeSelection -E "weka.attributeSelection.CfsSubsetEval -P 1 -E 1" -S  "weka.attributeSelection.BestFirst -D 1 -N 5" -i "${RANDOM_LOCATION}/${var}_onload.arff" -c 1 -o "${SET_LOCATION}/input/${var}_onload.arff"

#selected attribute counting
echo "Counting attributes of BestFit for Set 4 (${var})"
cat ${SET_LOCATION}/input/${var}_onload.arff | grep "@attribute" | awk -v label="${SET_LOCATION}/input/${var}_onload.arff|" '{print label, $2}' >> ${SET_LOCATION}/results/top_features_bf.csv

done < "$INPUT"
