#!/bin/bash
CLAZZ_PATH="-cp /home/anakinskywalker/weka-3-8-1/weka.jar:/home/anakinskywalker/weka-3-8-1/mtj.jar:/home/anakinskywalker/weka-3-8-1/model-eval.jar:/home/anakinskywalker/weka-3-8-1/model-eval-summary.jar:/home/anakinskywalker/jars/commons-cli-1.4.jar:/home/anakinskywalker/jars/commons-csv-1.5.jar:/home/anakinskywalker/jars/commons-math3-3.6.1.jar:/home/anakinskywalker/wekafiles/packages/isotonicRegression/isotonicRegression.jar:/home/anakinskywalker/wekafiles/packages/leastMedSquared/leastMedSquared.jar:/home/anakinskywalker/wekafiles/packages/paceRegression/paceRegression.jar:/home/anakinskywalker/wekafiles/packages/RBFNetwork/RBFNetwork.jar"
JVM_MEM=-Xmx3072m

usage()
{
	echo "usage: step5 [[-s setdir] | [-h]]"
}

echo "No of parameters" $#

if [ $# -ne 2 ]; then
	usage
	exit
fi

while [ "$1" != "" ]; do
	case $1 in
        -s | --setdir ) shift
						SET_LOCATION=$1
                        ;;
		-h | --help )   usage
                        exit
                        ;;
		* )				usage
						exit 1
	esac
	shift
done

echo "Cleaning results file"
> ${SET_LOCATION}/results/summary.csv

java $CLAZZ_PATH $JVM_MEM modelsummary.evaluation.ModelAccuracy -i ${SET_LOCATION}/results/evaluation.csv -o ${SET_LOCATION}/results/summary.csv -append true -debug false
