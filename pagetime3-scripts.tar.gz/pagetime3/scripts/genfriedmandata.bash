#!/bin/bash -x

#FRIEDMAN_LOCATION="../set1/output"
FRIEDMAN_LOCATION="../set3/output"
INPUT="./friedman-consolidation-list.txt"
#PREDICT_LOCATION="../set1/output"
PREDICT_LOCATION="../set3/output"


while IFS= read -r var
do

#awk -f consolidate.awk ${PREDICT_LOCATION}/${var}_rbfreg.csv ${PREDICT_LOCATION}/${var}_rbfnet.csv ${PREDICT_LOCATION}/${var}_pacer.csv ${PREDICT_LOCATION}/${var}_isor.csv ${PREDICT_LOCATION}/${var}_lms.csv ${PREDICT_LOCATION}/${var}_mlp.csv ${PREDICT_LOCATION}/${var}_lr.csv ${PREDICT_LOCATION}/${var}_slr.csv ${PREDICT_LOCATION}/${var}_smo.csv ${PREDICT_LOCATION}/${var}_dt.csv ${PREDICT_LOCATION}/${var}_m5r.csv ${PREDICT_LOCATION}/${var}_zr.csv ${PREDICT_LOCATION}/${var}_m5p.csv ${PREDICT_LOCATION}/${var}_ds.csv ${PREDICT_LOCATION}/${var}_randfor.csv ${PREDICT_LOCATION}/${var}_randtree.csv ${PREDICT_LOCATION}/${var}_reptree.csv ${PREDICT_LOCATION}/${var}_ibk.csv ${PREDICT_LOCATION}/${var}_lwl.csv > ${FRIEDMAN_LOCATION}/${var}.friedman

awk -f consolidate.awk ${PREDICT_LOCATION}/${var}_rbfreg.csv ${PREDICT_LOCATION}/${var}_pacer.csv ${PREDICT_LOCATION}/${var}_isor.csv ${PREDICT_LOCATION}/${var}_lms.csv ${PREDICT_LOCATION}/${var}_mlp.csv ${PREDICT_LOCATION}/${var}_lr.csv ${PREDICT_LOCATION}/${var}_slr.csv ${PREDICT_LOCATION}/${var}_smo.csv ${PREDICT_LOCATION}/${var}_dt.csv ${PREDICT_LOCATION}/${var}_m5r.csv ${PREDICT_LOCATION}/${var}_zr.csv ${PREDICT_LOCATION}/${var}_m5p.csv ${PREDICT_LOCATION}/${var}_ds.csv ${PREDICT_LOCATION}/${var}_randfor.csv ${PREDICT_LOCATION}/${var}_randtree.csv ${PREDICT_LOCATION}/${var}_reptree.csv ${PREDICT_LOCATION}/${var}_ibk.csv ${PREDICT_LOCATION}/${var}_lwl.csv > ${FRIEDMAN_LOCATION}/${var}.friedman


done < "$INPUT"
