package model.evaluation;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;


import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;

import model.evaluation.beans.ObsExpDataBean;

public class ObsExpDataReader {

	public ArrayList<ArrayList<ObsExpDataBean>> read(String filename, String debug,
			String avgOfStatistics) throws Exception {
		
		ArrayList<ArrayList<ObsExpDataBean>> logentriesarr = new ArrayList<ArrayList<ObsExpDataBean>>();
		ArrayList<ObsExpDataBean> logentries = new ArrayList<ObsExpDataBean>(); //initialize to prevent warning

		FileReader fr = new FileReader(filename);
		try {
			Iterable<CSVRecord> records = CSVFormat.RFC4180.withFirstRecordAsHeader().withIgnoreEmptyLines().parse(fr);
			for (CSVRecord record : records) {
			    String ins = record.get(ObsExpDataBean.INSTANCE);
			    String obs = record.get(ObsExpDataBean.OBSERVED);
			    String exp = record.get(ObsExpDataBean.EXPECTED);

			    ObsExpDataBean oedb = new ObsExpDataBean(Integer.parseInt(ins), 
						Double.parseDouble(obs),
						Double.parseDouble(exp));

				if (debug.equals("true") == true) {
				    System.out.println(oedb.toString());
				}

				//start of the set
				if (avgOfStatistics.equals("true") == true && Integer.parseInt(ins) == 1) {
					if (debug.equals("true") == true) {
						System.out.println("New set got");
					}
					if (logentries.size() > 0) {
						//entries from previous set
						logentriesarr.add(logentries);
					}
					logentries = new ArrayList<ObsExpDataBean>();
				}
				
				logentries.add(oedb);
			}
			
			//entries of the last set
			logentriesarr.add(logentries);
			
		} catch (FileNotFoundException fnfe) {
			fnfe.printStackTrace();
			fr.close();
			return null;
		}


		return logentriesarr;
	}
}
