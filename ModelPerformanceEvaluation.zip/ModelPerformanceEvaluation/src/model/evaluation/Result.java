package model.evaluation;

import java.text.DecimalFormat;

public class Result {

	public static String DELIMITER = "|";

	private String label;
	private String technique;
	private long   n;
	private String etime;
	private double r;
	private double maxMRE;
	private double MMRE;
	private double pred1;
	private double pred2;
	private double sumARE;
	private double medARE;
	private double SDARE;
	private double RMSE;
	private double NRMSE;
	private double relativeAbsError;
	private double relativeAbsErrorSquare;
	
	public Result(String label, String technique, long n, String etime, double r, double maxMRE, double MMRE,
			double pred1, double pred2, double sumARE, double medARE, double SDARE, double RMSE, double NRMSE,
			double relativeAbsError, double relativeAbsErrorSquare) {
		super();
		this.label = label;
		this.technique = technique;
		this.n = n;
		this.etime = etime;
		this.r = r;
		this.maxMRE = maxMRE;
		this.MMRE = MMRE;
		this.pred1 = pred1;
		this.pred2 = pred2;
		this.sumARE = sumARE;
		this.medARE = medARE;
		this.SDARE = SDARE;
		this.RMSE = RMSE;
		this.NRMSE = NRMSE;
		this.relativeAbsError = relativeAbsError;
		this.relativeAbsErrorSquare = relativeAbsErrorSquare;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer(128);
		DecimalFormat df = new DecimalFormat("###.##");

		sb.append(label);
		sb.append(DELIMITER);
		sb.append(technique);
		sb.append(DELIMITER);
		sb.append(n);
		sb.append(DELIMITER);
		sb.append(etime);
		sb.append(DELIMITER);
		sb.append(df.format(r));
		sb.append(DELIMITER);
		sb.append(df.format(maxMRE));
		sb.append(DELIMITER);
		sb.append(df.format(MMRE));
		sb.append(DELIMITER);
		sb.append(df.format(pred1));
		sb.append(DELIMITER);
		sb.append(df.format(pred2));
		sb.append(DELIMITER);
		sb.append(df.format(sumARE));
		sb.append(DELIMITER);
		sb.append(df.format(medARE));
		sb.append(DELIMITER);
		sb.append(df.format(SDARE));
		sb.append(DELIMITER);
		sb.append(df.format(RMSE));
		sb.append(DELIMITER);
		sb.append(df.format(NRMSE));
		sb.append(DELIMITER);
		sb.append(df.format(relativeAbsError));
		sb.append(DELIMITER);
		sb.append(df.format(relativeAbsErrorSquare));
		sb.append(DELIMITER);
		
		System.out.println(sb.toString());

		return sb.toString();
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getTechnique() {
		return technique;
	}

	public void setTechnique(String technique) {
		this.technique = technique;
	}

	public long getN() {
		return n;
	}

	public void setN(long n) {
		this.n = n;
	}

	public String getEtime() {
		return etime;
	}

	public void setEtime(String etime) {
		this.etime = etime;
	}

	public double getR() {
		return r;
	}

	public void setR(double r) {
		this.r = r;
	}

	public double getMaxMRE() {
		return maxMRE;
	}

	public void setMaxMRE(double maxMRE) {
		this.maxMRE = maxMRE;
	}

	public double getMMRE() {
		return MMRE;
	}

	public void setMMRE(double mMRE) {
		MMRE = mMRE;
	}

	public double getPred1() {
		return pred1;
	}

	public void setPred1(double pred1) {
		this.pred1 = pred1;
	}

	public double getPred2() {
		return pred2;
	}

	public void setPred2(double pred2) {
		this.pred2 = pred2;
	}

	public double getSumARE() {
		return sumARE;
	}

	public void setSumARE(double sumARE) {
		this.sumARE = sumARE;
	}

	public double getMedARE() {
		return medARE;
	}

	public void setMedARE(double medARE) {
		this.medARE = medARE;
	}

	public double getSDARE() {
		return SDARE;
	}

	public void setSDARE(double sDARE) {
		SDARE = sDARE;
	}

	public double getRMSE() {
		return RMSE;
	}

	public void setRMSE(double rMSE) {
		RMSE = rMSE;
	}

	public double getNRMSE() {
		return NRMSE;
	}

	public void setNRMSE(double nRMSE) {
		NRMSE = nRMSE;
	}

	public double getRelativeAbsError() {
		return relativeAbsError;
	}

	public void setRelativeAbsError(double relativeAbsError) {
		this.relativeAbsError = relativeAbsError;
	}

	public double getRelativeAbsErrorSquare() {
		return relativeAbsErrorSquare;
	}

	public void setRelativeAbsErrorSquare(double relativeAbsErrorSquare) {
		this.relativeAbsErrorSquare = relativeAbsErrorSquare;
	}


}
