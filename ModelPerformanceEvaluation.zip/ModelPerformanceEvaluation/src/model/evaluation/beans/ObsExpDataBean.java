package model.evaluation.beans;

public class ObsExpDataBean {
	
	public static final int  INSTANCE = 0;
	public static final int  OBSERVED = 1;
	public static final int  EXPECTED = 2;

	int    instance;
	double obs;
	double exp;
	
	double residualError;								//residual error
	double absoluteResidualError;  						//absolute residual error
	double squareOfResidualError;  						//square of residual error
	double relativeError; 								//relative error
	double magnitudeRelativeError;						//magnitude of relative error
	double z;											//ratio of estimate to actual
	double absoluteResidualErrorComparedToBaseline1;	    //absolute residual error when compared to simple predictor 1
	double squareOfabsoluteResidualErrorComparedToBaseline1;//square of absoluteResidualErrorComparision
	
	
	public ObsExpDataBean(int instance, double obs, double exp) {
		super();
		this.instance = instance;
		this.obs = obs;
		this.exp = exp;
		this.residualError   = obs - exp;
		this.absoluteResidualError = Math.abs(this.residualError);
		this.squareOfResidualError = Math.pow(this.residualError, 2);
		this.relativeError = this.residualError/this.obs;
		this.magnitudeRelativeError = this.absoluteResidualError/this.obs;
		this.z = this.exp/this.obs;
	}
	
	public int getInstance() {
		return instance;
	}


	public void setInstance(int instance) {
		this.instance = instance;
	}


	public double getObs() {
		return obs;
	}


	public void setObs(double obs) {
		this.obs = obs;
	}


	public double getExp() {
		return exp;
	}


	public void setExp(double exp) {
		this.exp = exp;
	}


	public double getResidualError() {
		return residualError;
	}


	public void setResidualError(double residualError) {
		this.residualError = residualError;
	}


	public double getAbsoluteResidualError() {
		return absoluteResidualError;
	}


	public void setAbsoluteResidualError(double absoluteResidualError) {
		this.absoluteResidualError = absoluteResidualError;
	}


	public double getSquareOfResidualError() {
		return squareOfResidualError;
	}


	public void setSquareOfResidualError(double squareOfResidualError) {
		this.squareOfResidualError = squareOfResidualError;
	}


	public double getRelativeError() {
		return relativeError;
	}


	public void setRelativeError(double relativeError) {
		this.relativeError = relativeError;
	}


	public double getMagnitudeRelativeError() {
		return magnitudeRelativeError;
	}


	public void setMagnitudeRelativeError(double magnitudeRelativeError) {
		this.magnitudeRelativeError = magnitudeRelativeError;
	}


	public double getZ() {
		return z;
	}


	public void setZ(double z) {
		this.z = z;
	}


	public double getAbsoluteResidualErrorComparedToBaseline1() {
		return absoluteResidualErrorComparedToBaseline1;
	}


	public void setAbsoluteResidualErrorComparedToBaseline1(double baseline1) {
		this.absoluteResidualErrorComparedToBaseline1 = Math.abs(obs - baseline1);
		this.squareOfabsoluteResidualErrorComparedToBaseline1 = Math.pow(this.absoluteResidualErrorComparedToBaseline1, 2);
	}

	public double getSquareOfabsoluteResidualErrorComparedToBaseline1() {
		return squareOfabsoluteResidualErrorComparedToBaseline1;
	}
	
	public String toString() {
		return "ObsExpDataBean [instance=" + instance + ", obs=" + obs + ", exp=" + exp + ", residualError="
				+ residualError + ", absoluteResidualError=" + absoluteResidualError + ", squareOfResidualError="
				+ squareOfResidualError + ", relativeError=" + relativeError + ", magnitudeRelativeError="
				+ magnitudeRelativeError + ", z=" + z + ", absoluteResidualErrorComparedToBaseline1="
				+ absoluteResidualErrorComparedToBaseline1 + ", squareOfabsoluteResidualErrorComparedToBaseline1="
				+ squareOfabsoluteResidualErrorComparedToBaseline1 + "]";
	}

}
